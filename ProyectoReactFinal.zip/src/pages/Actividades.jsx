const Actividades = () => (
  <div className="p-4">
    <h1 className="text-xl font-bold">Actividades del Curso</h1>
    <p>Resumen de los sprints realizados, tareas, y aprendizajes.</p>
  </div>
);

export default Actividades;