const Sistema = () => (
  <div className="p-4">
    <h1 className="text-xl font-bold">Sistema Implementado</h1>
    <p>Descripción del sistema desarrollado, objetivos y funcionalidades.</p>
  </div>
);

export default Sistema;